import React from "react";
import { useParams, useNavigate } from "react-router-dom";

const drinks = {
  "COCA-COLA": {
    "image": "https://i.imgur.com/6XYD1Tf.png",
    "description": "\nA Coca-cola \u00e9 uma das bebidas mais consumidas em todo o mundo. Al\u00e9m do seu sabor inconfund\u00edvel, ela tamb\u00e9m \u00e9 usada para preparar drinks incr\u00edveis.\nCombina\u00e7\u00f5es: Rum, Fernet, Vodka, Whisky, gelo e lim\u00e3o.\nDica: Sirva bem gelada e misture suavemente para manter a efervesc\u00eancia e o sabor \u00fanico.\n"
  },
  "FERNET-BRANCO": {
    "image": "https://i.imgur.com/QNsBy7Y.png",
    "description": "\nO Fernet Branco, com seu sabor amargo e herbal, pode ser combinado com refrigerantes para suavizar o gosto e criar drinks sofisticados.\nCombina\u00e7\u00f5es: Coca-Cola, soda, energ\u00e9tico, gelo.\nDica: Perfeito ap\u00f3s as refei\u00e7\u00f5es como digestivo ou para criar coquet\u00e9is intensos.\n"
  },
  "PACOTE DE GELO": {
    "image": "https://i.imgur.com/G9HkvWx.png",
    "description": "\nO gelo \u00e9 essencial para a maioria dos drinks. Ele mant\u00e9m as bebidas refrescantes e ajuda a liberar os sabores dos ingredientes.\nCombina\u00e7\u00f5es: Todas as bebidas.\nDica: Use gelo claro (feito de \u00e1gua filtrada) e evite recongelar gelo derretido.\n"
  },
  "JACK DANIELS": {
    "image": "https://i.imgur.com/fIQUTAI.png",
    "description": "\nO Jack Daniel\u2019s \u00e9 conhecido pelo seu sabor suave e notas adocicadas. Ideal para ser apreciado puro ou misturado.\nCombina\u00e7\u00f5es: Coca-Cola, caf\u00e9, amaretto, gelo.\nDica: Uma dose de Jack Daniel\u2019s harmoniza bem com sobremesas de chocolate e pratos com carne grelhada ou parrilla.\n"
  },
  "CHIVAS 18": {
    "image": "https://i.imgur.com/Dm0mNcx.png",
    "description": "\nChivas Regal 18 \u00e9 um blended scotch whisky sofisticado, envelhecido por 18 anos, oferecendo uma experi\u00eancia encorpada e suave.\nCombina\u00e7\u00f5es: \u00c1gua com g\u00e1s, gelo, vermute seco.\nDica: Deguste puro para apreciar sua complexidade ou crie coquet\u00e9is cl\u00e1ssicos como Rob Roy.\n"
  },
  "VELHO BARREIRO": {
    "image": "https://i.imgur.com/TtBhqlR.png",
    "description": "\nA Velho Barreiro \u00e9 uma cacha\u00e7a brasileira tradicional, \u00f3tima para caipirinhas e outras misturas refrescantes.\nCombina\u00e7\u00f5es: Lim\u00e3o, a\u00e7\u00facar, mel, abacaxi, hortel\u00e3.\nDica: Sirva com bastante gelo para real\u00e7ar o sabor e suavizar o teor alco\u00f3lico.\n"
  }
};

export default function DrinkDetail() {
  const { name } = useParams();
  const navigate = useNavigate();
  const drink = drinks[name];

  return (
    <div className="container">
      <div className="header">{name}</div>
      <img className="detail-img" src={drink.image} alt={name} />
      <div className="description">
        <pre style={whiteSpace: "pre-wrap"}>{drink.description}</pre>
      </div>
      <button className="back-btn" onClick={() => navigate("/")}>
        Voltar
      </button>
    </div>
  );
}