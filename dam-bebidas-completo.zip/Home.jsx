import React from "react";
import { useNavigate } from "react-router-dom";

const drinks = [
  {
    "name": "COCA-COLA",
    "image": "https://i.imgur.com/6XYD1Tf.png"
  },
  {
    "name": "FERNET-BRANCO",
    "image": "https://i.imgur.com/QNsBy7Y.png"
  },
  {
    "name": "PACOTE DE GELO",
    "image": "https://i.imgur.com/G9HkvWx.png"
  },
  {
    "name": "JACK DANIELS",
    "image": "https://i.imgur.com/fIQUTAI.png"
  },
  {
    "name": "CHIVAS 18",
    "image": "https://i.imgur.com/Dm0mNcx.png"
  },
  {
    "name": "VELHO BARREIRO",
    "image": "https://i.imgur.com/TtBhqlR.png"
  }
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="container">
      <div className="header">DAM BEBIDAS</div>
      <div className="grid">
        {drinks.map((drink) => (
          <div
            key={drink.name}
            className="card"
            onClick={() => navigate(`/drink/${drink.name}`)}
          >
            <img src={drink.image} alt={drink.name} />
            <div className="card-name">{drink.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
}